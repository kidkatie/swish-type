<?php 
$width=$instance['width'];
$height=$instance['height'];
$title = $instance['title'];
$postObj = $wpQuery->post;

if($wpQuery->have_posts()){
	?>	
<?php if($title==''):?>
	<?php if($cat !=0):?>
		<div class="widget-title-cover"><h4 class="widget-title"><a href="<?php echo get_category_link($cat)?>" title="<?php echo get_cat_name($cat)?>"><span><?php echo get_cat_name($cat)?></span></a></h4></div>
	<?php endif;?>
<?php endif;?>

<div class="latest_style_2">
	<?php 
	while ($wpQuery->have_posts()){
		$wpQuery->the_post();
		$postObj = $wpQuery->post;

		$imgUrl = wp_get_attachment_url(get_post_thumbnail_id($postObj->ID));
	
		if(!empty($imgUrl)){
			$imgUrl = $this->get_new_img_url($imgUrl, $width, $height);
		}
		
	?>
	<div class="latest_style_2_item">
		<?php if(!empty($imgUrl)): ?>
			<figure class="alith_news_img"><a href="<?php the_permalink();?>"><img src="<?php echo esc_attr($imgUrl);?>" alt="<?php the_title_attribute();?>"/></a></figure>
		<?php endif; ?>
		<h6><a href="<?php the_permalink();?>"><?php the_title();?></a></h6>
	</div>

	<?php
		} //end while			
	} //end if	
	?>	

</div>

	
