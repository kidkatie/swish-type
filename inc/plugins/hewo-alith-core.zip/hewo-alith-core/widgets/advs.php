<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
//Adv widget
add_action('widgets_init', 'alitheme_register_adv_widget');
function alitheme_register_adv_widget()
{
    register_widget('Alitheme_Theme_Widget_Advs');
}
// Start class
if (!class_exists('Alitheme_Theme_Widget_Advs')):
class Alitheme_Theme_Widget_Advs extends WP_Widget {
	public function __construct()
		  {
			parent::__construct(
			  'alitheme_adv', 
			  esc_html__('Alitheme Advertise', 'alith-core' ),
			  array(
				'description' => esc_html__('Display banner and link', 'alith-core' )
			  )
			);
		  }
    function widget($args, $instance) {        
        extract( $args );
		$title = apply_filters('widget_title', $instance['title']);
		$title = (empty($title))? '': $title;
		
		$image 		= empty($instance['image']) 	? '' : $instance['image'];
		$content 	= empty($instance['content']) 	? '' : $instance['content'];
		$link 		= empty($instance['link']) 		? '' : $instance['link'];
		
		echo $before_widget;  
		if(!empty($title)){
				echo $before_title . $title . $after_title;
			}
		?>		
		<div class="alith-banner-adv">
			<div class="adv-thumb"><a href="<?php echo $link; ?>"><img src="<?php echo $image; ?> " alt="ads banner" class="aligncenter"></a></div>
			<p><?php echo $content; ?></p>
		</div>
        <?php
		echo $after_widget;
    }
    function update($new_instance, $old_instance) {                
        return $new_instance;
    }
    function form($instance) {                
		$title 		= empty($instance['title'])		? '':  esc_attr($instance['title']);		
		$image 		= empty($instance['image']) 	? '':  esc_attr($instance['image']);
		$content 	= empty($instance['content']) 	? '':  esc_attr($instance['content']);
		$link 		= empty($instance['link']) 		? '':  esc_attr($instance['link']);
       ?>
      <p>
		  <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'alith-core'); ?> 
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		  </label>
	  </p>
      <?php
   $arg = array(
        'parent_div_class'=> 'custom-image-upload',
        'field_name' => $this->get_field_name('image'),
        'field_id' => 'upload_banner',
        'field_class' => 'upload_image_field',
        'upload_button_id' => 'upload_banner_button',
        'upload_button_class' => 'upload_banner_button',
        'upload_button_text' => 'Upload',
        'remove_button_id' => 'remove_banner',
        'remove_button_class' => 'remove_banner_button',
        'remove_button_text' => 'Remove'
        );
       eiu_add_media_custom($arg,false,$image);
   ?>      
      <p>
		  <label for="<?php echo $this->get_field_id('content'); ?>"><?php _e('Content:', 'alith-core'); ?> 
			<textarea class="widefat content" rows="10" id="<?php echo $this->get_field_id('content'); ?>" name="<?php echo $this->get_field_name('content'); ?>" ><?php echo $content; ?></textarea>
		  </label>
	  </p>
      <p>
		  <label for="<?php echo $this->get_field_id('link'); ?>"><?php _e('Link:', 'alith-core'); ?> 
			<input class="widefat <?php echo $this->get_field_id('link'); ?>" id="<?php echo $this->get_field_id('link'); ?>" name="<?php echo $this->get_field_name('link'); ?>" type="text" value="<?php echo $link; ?>" />
		  </label>
	  </p>
    <?php 
    }
} 
endif;
