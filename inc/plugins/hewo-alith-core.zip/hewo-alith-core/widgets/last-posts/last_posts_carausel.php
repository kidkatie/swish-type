<?php 
$width=$instance['width'];
$height=$instance['height'];
$title = $instance['title'];
$postObj = $wpQuery->post;

if($wpQuery->have_posts()){
?>



<div class="owl-carousel owl-theme js carausel_slider section_margin" id="slider-small">
	<?php 
	while ($wpQuery->have_posts()){
		$wpQuery->the_post();
		$postObj = $wpQuery->post;

		$imgUrl = wp_get_attachment_url(get_post_thumbnail_id($postObj->ID));
	
		if(!empty($imgUrl)){
			$imgUrl = $this->get_new_img_url($imgUrl, $width, $height);
		}
		
	?>
	<div class="item px-2">
		<div class="alith_latest_trading_img_position_relative">
			<?php if(!empty($imgUrl)): ?>
			<figure class="alith_post_thumb">
				<a href="<?php the_permalink();?>"><img class="mini-widget-thumb" src="<?php echo esc_attr($imgUrl);?>" alt="<?php the_title_attribute();?>"/></a>
			</figure>
			<?php endif; ?>
			<div class="alith_post_title_small">
				<h6><a href="<?php the_permalink();?>"><?php echo wp_trim_words( get_the_title(), 6 );?></a></h6>
				<div class="post_meta">
					<span class="meta_date"><i class="fa fa-clock-o" aria-hidden="true"></i><?php echo get_the_date(); ?></span>
				</div>
			</div>
		</div>
	</div>

	<?php
		} //end while			
	} //end if	
	?>	

</div>

	
