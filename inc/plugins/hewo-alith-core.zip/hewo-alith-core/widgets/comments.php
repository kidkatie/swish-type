<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
//Comment widget
add_action('widgets_init', 'alitheme_register_comment_widget');
function alitheme_register_comment_widget()
{
    register_widget('Alitheme_Theme_Widget_Comment');
}
// Start class
if ( ! class_exists( 'Alitheme_Theme_Widget_Comment' ) ) {
	class Alitheme_Theme_Widget_Comment extends WP_Widget {
		public function __construct()
		  {
			parent::__construct(
			  'alitheme_comment', 
			  esc_html__('Alitheme Comment', 'alith-core' ),
			  array(
				'description' => esc_html__('Comment with avatar', 'alith-core' )
			  )
			);
		  }
		function widget( $args, $instance ) {
			extract( $args );
			
			$title = apply_filters('widget_title', $instance['title']);
			$title = (empty($title))? '': $title;
			
			echo $before_widget;
			
			if(!empty($title)){
				echo $before_title . $title . $after_title;
			}			
			$number = isset( $instance['number'] ) ? $instance['number'] : '3';
			
			echo '<ul class="alith-recent-comments-widget alith-clr">';
				// Query Comments
				$comments = get_comments( array(
					'number'      => $number,
					'status'      => 'approve',
					'post_status' => 'publish',
					'type'        => 'comment',
				) );
				// Display comments
				if ( $comments ) :
					// Loop through comments
					foreach ( $comments as $comment ) :
						// Get comment ID
						$comment_id   = $comment->comment_ID;
						$comment_link = get_permalink( $comment->comment_post_ID ) . '#comment-' . $comment_id;
						// Title alt
						$title_alt = esc_html__( 'Read Comment', 'alith-core' );
						echo '<li class="alith-clr">';
							echo '<a href="'. esc_url( $comment_link ) .'" title="'. esc_attr( $title_alt ) .'" class="alith-avatar">';
								echo get_avatar( $comment->comment_author_email, '50' );
							echo '</a>';
							echo '<div class="alith-details">';
								echo '<strong>'. esc_html( get_comment_author( $comment_id ) ) .':</strong>';
								echo ' <span>'. wp_trim_words( $comment->comment_content, '10', '&hellip;' ) .'</span>';
								echo '<a href="'. esc_url( $comment_link ) .'" title="'. esc_attr__( 'more', 'alith-core' ) .'" class="alith-more"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>';
							echo '</div>';
						echo '</li>';
					endforeach;
				// Display no comments notice
				else :
					echo '<li>'. esc_html__( 'No comments yet.', 'alith-core' ) .'</li>';
				endif;
			echo '</ul>';
			
			echo $after_widget;
		}
		function update( $new_instance, $old_instance ) {
			$instance           = $old_instance;
			$instance['title']  = strip_tags( $new_instance['title'] );
			$instance['number'] = strip_tags( $new_instance['number'] );
			return $instance;
		}
		/**
		 * Back-end widget form.
		 *
		 * @see WP_Widget::form()
		 * @since 1.0.0
		 *
		 * @param array $instance Previously saved values from database.
		 */
		function form( $instance ) {
			extract( wp_parse_args( ( array ) $instance, array(
				'title'  => '',
				'number' => '3',
			) ) ); ?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'alith-core' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title', 'alith-core' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number to Show:', 'alith-core' ); ?></label> 
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
			</p>
			<?php
		}
	}
}