<?php
/**
 * Plugin Name: Hewo Core
 * Plugin URI: http://alithemes.com
 * Description: Core Features for Hewo, this is required plugin for this theme
 * Version: 1.0 
 * Author: alithemes.com
 * Author URI: http://alithemes.com
 * License: GPLv2 or later
 */
 
 // No direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Plugin Folder URL
if ( ! defined( 'ALITH_CORE_PLUGIN_URL' ) ) {
	define( 'ALITH_CORE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
} 
if ( ! defined( 'ALITH_CORE_PLUGIN_DIR' ) ) {
	define( 'ALITH_CORE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
} 

//helper
include_once( 'inc/helper/helper.php' );
include_once( 'inc/helper/html.php' );
include_once( 'inc/helper/demo-importer.php' );
include_once( 'inc/redux/framework.php' );

//widgets
include_once( 'widgets/advs.php' );
include_once( 'widgets/comments.php' );
include_once( 'widgets/instagram.php' );
include_once( 'widgets/last_posts.php' );
include_once( 'widgets/twitter.php' );
include_once( 'widgets/tags.php' );



