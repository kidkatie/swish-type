<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
//Latest widget
add_action('widgets_init', 'alitheme_register_lastpost_widget');
function alitheme_register_lastpost_widget()
{
    register_widget('Alitheme_Theme_Widget_LastPost');
}
// Start class
if (!class_exists('Alitheme_Theme_Widget_LastPost')):
class Alitheme_Theme_Widget_LastPost extends WP_Widget {
	public function __construct() {
		parent::__construct(
			  'alitheme_lastpost', 
			  esc_html__('Alitheme Lastpost', 'alith-core' ),
			  array(
				'description' => esc_html__('Display the latest posts from category', 'alith-core' )
			  )
			);	

	}	
	public function widget( $args, $instance ) {
		extract($args);
		$title 							= apply_filters('widget_title', $instance['title']);
		$title 							= (empty($title))? esc_html__('', 'alith-core'): $title;
		$cat 							= (empty($instance['cat']))? 0: $instance['cat'];
		$type 							= (empty($instance['type']))? 'only': $instance['type'];
		$in_ex_post_format 				= (empty($instance['in_ex_post_format']))? 'only-get': $instance['in_ex_post_format'];
		$post_format 					= (empty($instance['post_format']))? 'standard': $instance['post_format'];		
		$items 							= (empty($instance['items']))? 5: $instance['items'];	
		$width 							= (empty($instance['width']))? 300: $instance['width'];
		$height 						= (empty($instance['height']))? 126: $instance['height'];
		$show_type 						= (empty($instance['show_type']))? 'sidebar': $instance['show_type'];
		
			
		echo $before_widget;
		if(!empty($title)){
			echo $before_title . $title . $after_title;
		}
		

		$args = array(
				'post_type' 			=> 'post',
				'orderby' 				=> 'ID',
				'order'					=> 'DESC',
				'posts_per_page' 		=> $items,
				'post_status' 			=>'publish',
				'ignore_sticky_posts' 	=> true
		);
			
		if($cat != 0){
			if($type == 'only'){
				$args['category__in'] = array($cat);
			}else{
				$args['cat'] = $cat;
			}
		}
		
		if($in_ex_post_format != 'only-get') {
			if($post_format != 'standard'){
				$tax_query = array(
						array(
								'field' => 'slug',
								'terms'=>array('post-format-'. $post_format),
								'taxonomy' => 'post_format',
								'operator' => 'NOT IN'
						)
				);
				$args['tax_query'] = $tax_query;
			}
		} else {
			if($post_format != 'standard'){
				$tax_query = array(
						array(
								'field' => 'slug',
								'terms'=>array('post-format-'. $post_format),
								'taxonomy' => 'post_format',
								'operator' => 'IN'
						)
				);
				$args['tax_query'] = $tax_query;
			}
		}
			
		$wpQuery = new WP_Query($args);
		//display on front-page	
		if($show_type == 'style-1' ){
			require ('last-posts/last_posts_style_1.php');
		} else if($show_type == 'style-2'){
			require ('last-posts/last_posts_style_2.php');
		} else if($show_type == 'style-3'){
			require ('last-posts/last_posts_style_3.php');
		} else if($show_type == 'style-4'){
			require ('last-posts/last_posts_style_4.php');
		} else if($show_type == 'carausel'){
			require ('last-posts/last_posts_carausel.php');
		}
		
		wp_reset_postdata();
		
		echo $after_widget;
	}
	
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
	
		$instance['title'] 						= strip_tags($new_instance['title']);
		$instance['cat'] 						= strip_tags($new_instance['cat']);
		$instance['type'] 						= strip_tags($new_instance['type']);
		$instance['in_ex_post_format'] 			= strip_tags($new_instance['in_ex_post_format']);
		$instance['post_format']				= strip_tags($new_instance['post_format']);
		$instance['items']						= strip_tags($new_instance['items']);
		$instance['show_type']					= strip_tags($new_instance['show_type']);
		$instance['width']						= strip_tags($new_instance['width']);
		$instance['height']						= strip_tags($new_instance['height']);
	
		return $instance;
	}
	
	public function form( $instance ) {
		$htmlObj =  new HtmlGender();
			
		//Title
		$inputID 	= $this->get_field_id('title');
		$inputName 	= $this->get_field_name('title');
		$inputValue = @$instance['title'];
		$arr = array('class' =>'widefat','id' => $inputID);
		$html		= $htmlObj->label(esc_html__('Title', 'alith-core'),array('for'=>$inputID))
					. $htmlObj->textbox($inputName,$inputValue,$arr);
		echo wp_kses($htmlObj->pTag($html),
			array(
			'p' => array(),
			'label' => array(
						'for' => array()
					),
			'input' => array(
						'type'  => array(),
						'name'  => array(),
						'class' => array(),
						'id'    => array(),
						'value' => array()
					)
		));
		
		//Category
		$inputID 	= $this->get_field_id('cat');
		$inputName 	= $this->get_field_name('cat');
		$inputValue = @$instance['cat'];		
		
		$args = array(
				'show_option_all'    => esc_html__('All category', 'alith-core'),
				'show_option_none'   => '',
				'orderby'            => 'ID',
				'order'              => 'ASC',
				'show_count'         => 1,
				'hide_empty'         => 1,
				'child_of'           => 0,
				'exclude'            => '',
				'echo'               => 0,
				'selected'           => $inputValue,
				'hierarchical'       => 1,
				'name'               => $inputName,
				'id'                 => $inputID,
				'class'              => 'widefat',
				'depth'              => 0,
				'tab_index'          => 0,
				'taxonomy'           => 'category',
				'hide_if_empty'      => false,
		);
		
		$html		= $htmlObj->label(esc_html__('Categories', 'alith-core'),array('for'=>$inputID))
						. wp_dropdown_categories($args);
		echo wp_kses($htmlObj->pTag($html),
			array(
			'p' => array(),
			'label' => array(
						'for' => array()
					),
			'select' => array(
						'name'  => array(),
						'class'  => array(),
						'id' => array(),			

					),
			'option'    => array(
							'value' 	=> array(),
							'selected' 	=> array()
						),
		));
		
		//Type Show
		$inputID 	= $this->get_field_id('type');
		$inputName 	= $this->get_field_name('type');
		$inputValue = @$instance['type'];
		$arr 		= array('class' =>'widefat','id' => $inputID);
		$options['data'] = array(
								'only' => esc_html__('Only category', 'alith-core'),
								'child' => esc_html__('Include child', 'alith-core')
								);
		$html		= $htmlObj->label(esc_html__('Show Post in category', 'alith-core'),array('for'=>$inputID))
					.	$htmlObj->selectbox($inputName,$inputValue,$arr,$options);
		echo wp_kses($htmlObj->pTag($html),
			array(
			'p' => array(),
			'label' => array(
						'for' => array()
					),
			'select' => array(
						'name'  => array(),
						'class'  => array(),
						'id' => array(),			

					),
			'option'    => array(
							'value' 	=> array(),
							'selected' 	=> array()
						),
		));
		
		//include or exclude post-format
		$inputID 	= $this->get_field_id('in_ex_post_format');
		$inputName 	= $this->get_field_name('in_ex_post_format');
		$inputValue = @$instance['in_ex_post_format'];
		$arr 		= array('class' =>'widefat','id' => $inputID);
		$options['data'] = array(
								'exclude' => esc_html__('Exclude post format below', 'alith-core'),
								'only-get' => esc_html__('Only post format below', 'alith-core')
								);
		$html		= $htmlObj->label(esc_html__('Include or Exclude', 'alith-core'),array('for'=>$inputID))
					.	$htmlObj->selectbox($inputName,$inputValue,$arr,$options);
		echo wp_kses($htmlObj->pTag($html),
			array(
			'p' => array(),
			'label' => array(
						'for' => array()
					),
			'select' => array(
						'name'  => array(),
						'class'  => array(),
						'id' => array(),			

					),
			'option'    => array(
							'value' 	=> array(),
							'selected' 	=> array()
						),
		));

		//Post Format
		$inputID 	= $this->get_field_id('post_format');
		$inputName 	= $this->get_field_name('post_format');
		$inputValue = @$instance['post_format'];
		$arr 		= array('class' =>'widefat','id' => $inputID);
		$tmp 		= get_theme_support('post-formats');
		$tmp 		= $tmp[0];
		
		$options['data'] = array(
				'standard' => 'Standard'
		);
		for($i=0; $i< count($tmp); $i++){
				$options['data'][$tmp[$i]] = $tmp[$i];
		}
		$html		= $htmlObj->label(esc_html__('Post Format', 'alith-core'),array('for'=>$inputID))
						.	$htmlObj->selectbox($inputName,$inputValue,$arr,$options);
		echo wp_kses($htmlObj->pTag($html),
			array(
			'p' => array(),
			'label' => array(
						'for' => array()
					),
			'select' => array(
						'name'  => array(),
						'class'  => array(),
						'id' => array(),			

					),
			'option'    => array(
							'value' 	=> array(),
							'selected' 	=> array()
						),
		));
		
		//Type
		$inputID 	= $this->get_field_id('show_type');
		$inputName 	= $this->get_field_name('show_type');
		$inputValue = @$instance['show_type'];
		$arr 		= array('class' =>'widefat','id' => $inputID);
		
		$options['data'] = array(
				'style-1' 		=> esc_html__('style-1', 'alith-core' ),
				'style-2' 		=> esc_html__('style-2', 'alith-core' ),
				'style-3' 		=> esc_html__('style-3', 'alith-core' ),
				'style-4' 		=> esc_html__('style-4', 'alith-core' ),				
				'carausel' 		=> esc_html__('Carausel', 'alith-core' ),				
		);
		
		$html		= $htmlObj->label(esc_html__('Show Type', 'alith-core'),array('for'=>$inputID))
		.	$htmlObj->selectbox($inputName,$inputValue,$arr,$options);
		echo wp_kses($htmlObj->pTag($html),
			array(
			'p' => array(),
			'label' => array(
						'for' => array()
					),
			'select' => array(
						'name'  => array(),
						'class'  => array(),
						'id' => array(),			

					),
			'option'    => array(
							'value' 	=> array(),
							'selected' 	=> array()
						),
		));
		
		//Item
		$inputID 	= $this->get_field_id('items');
		$inputName 	= $this->get_field_name('items');
		$inputValue = @$instance['items'];
		$arr 		= array('class' =>'widefat','id' => $inputID);
		$html		= $htmlObj->label(esc_html__('Items', 'alith-core'),array('for'=>$inputID))
						. $htmlObj->textbox($inputName,$inputValue,$arr);
		echo wp_kses($htmlObj->pTag($html),
			array(
			'p' => array(),
			'label' => array(
						'for' => array()
					),
			'input' => array(
						'type'  => array(),
						'name'  => array(),
						'class' => array(),
						'id'    => array(),
						'value' => array()
					)
		));
		
		//Width
		$inputID 	= $this->get_field_id('width');
		$inputName 	= $this->get_field_name('width');
		$inputValue = @$instance['width'];
		$arr 		= array('class' =>'widefat','id' => $inputID);
		$html		= $htmlObj->label(esc_html__('Image Width', 'alith-core'),array('for'=>$inputID))
		. $htmlObj->textbox($inputName,$inputValue,$arr);
		echo wp_kses($htmlObj->pTag($html),
			array(
			'p' => array(),
			'label' => array(
						'for' => array()
					),
			'input' => array(
						'type'  => array(),
						'name'  => array(),
						'class' => array(),
						'id'    => array(),
						'value' => array()
					)
		));
		
		//Height
		$inputID 	= $this->get_field_id('height');
		$inputName 	= $this->get_field_name('height');
		$inputValue = @$instance['height'];
		$arr 		= array('class' =>'widefat','id' => $inputID);
		$html		= $htmlObj->label(esc_html__('Image height', 'alith-core'),array('for'=>$inputID))
		. $htmlObj->textbox($inputName,$inputValue,$arr);
		echo wp_kses($htmlObj->pTag($html),
			array(
			'p' => array(),
			'label' => array(
						'for' => array()
					),
			'input' => array(
						'type'  => array(),
						'name'  => array(),
						'class' => array(),
						'id'    => array(),
						'value' => array()
					)
		));
	}

	private function get_new_img_url($imgUrl, $width = 0, $heigt = 0 ,	$suffixes = '-alith-resize-'){
		$suffixes = $suffixes . $width . 'x'. $heigt;
	
		//get name of current image
		preg_match("/[^\/|\\\]+$/", $imgUrl, $currentName);
		$currentName = $currentName[0];
	
		//create new name for image base on old name
		$tmpFileName = explode('.', $currentName);
		$newFileName = $tmpFileName[0] . $suffixes . '.' . $tmpFileName[1];
	
		//convert URL to PATH
		$tmp 	= explode('/wp-content/', $imgUrl);
		$imgDir = ABSPATH.'wp-content/' . $tmp[1];
	
	
		$newImgDir = str_replace($currentName, $newFileName, $imgDir);
		if(!file_exists($newImgDir)){
			$wpImageEditor =  wp_get_image_editor( $imgDir);
			if ( ! is_wp_error( $wpImageEditor ) ) {
				$wpImageEditor->resize($width, $heigt, array('center','center'));
				$wpImageEditor->save( $newImgDir);
			}
		}
		$newImgUrl= str_replace($currentName, $newFileName, $imgUrl);
	
		return $newImgUrl;
	}

	
}
endif; // class_exists