<?php 
$width=$instance['width'];
$height=$instance['height'];
$title = $instance['title'];
$postObj = $wpQuery->post;
$count = 1;

if($wpQuery->have_posts()){
	?>	
<?php if($title==''):?>
	<?php if($cat !=0):?>
		<div class="widget-title-cover"><h4 class="widget-title"><a href="<?php echo get_category_link($cat)?>" title="<?php echo get_cat_name($cat)?>"><span><?php echo get_cat_name($cat)?></span></a></h4></div>
	<?php endif;?>
<?php endif;?>

<div class="latest_style_3">
	<?php 
	while ($wpQuery->have_posts()){
		$wpQuery->the_post();
		$postObj = $wpQuery->post;

		$imgUrl = wp_get_attachment_url(get_post_thumbnail_id($postObj->ID));
	
		if(!empty($imgUrl)){
			$imgUrl = $this->get_new_img_url($imgUrl, $width, $height);
		}
		
	?>
	<div class="latest_style_3_item <?php if (is_sticky()) echo 'sticky'; ?>">		
		<div class="row h-100">
			<div class="col-1 align-self-center">
				<span class="item-count"><?php echo $count; ?>.</span>			
			</div>
			<div class="col-10 align-self-center">
				<h6><a title="<?php the_title_attribute();?>" href="<?php the_permalink();?>"><?php the_title();?></a></h6>				
			</div>
		</div>
	</div>
	<?php
		$count ++;
		} //end while			
	} //end if	
	?>	

</div>

	
