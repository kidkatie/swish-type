<?php
if ( ! defined ( 'ABSPATH' ) ) {
	exit;
}
//About widget
add_action('widgets_init', 'alitheme_register_instagram_widget');
function alitheme_register_instagram_widget()
{
    register_widget('Alitheme_Theme_Widget_Instagram');
}
if ( ! class_exists( 'Alitheme_Theme_Widget_Instagram' ) ) {
	class Alitheme_Theme_Widget_Instagram extends WP_Widget {
		public function __construct() {
		parent::__construct(
			'null-instagram-feed',
			__( 'Alitheme Instagram', 'alith-core' ),
			array(
				'classname' => 'null-instagram-feed',
				'description' => esc_html__( 'Displays your latest Instagram photos', 'alith-core' ),
				'customize_selective_refresh' => true,
			)
		);
	}

	public function widget( $args, $instance ) {

		$title = empty( $instance['title'] ) ? '' : apply_filters( 'widget_title', $instance['title'] );
		$username = empty( $instance['username'] ) ? '' : $instance['username'];
		$limit = empty( $instance['number'] ) ? 8 : $instance['number'];
		$size = empty( $instance['size'] ) ? 'thumbnail' : $instance['size'];
		$target = empty( $instance['target'] ) ? '_self' : $instance['target'];
		$link = empty( $instance['link'] ) ? '' : $instance['link'];
		$columns     = empty( $instance['columns'] ) ? '4' : $instance['columns'];
		$columns_gap = empty( $instance['columns_gap'] ) ? '10' : $instance['columns_gap'];
		
		echo $args['before_widget'];

		if ( ! empty( $title ) ) { echo $args['before_title'] . wp_kses_post( $title ) . $args['after_title']; };

		do_action( 'wpiw_before_widget', $instance );

		if ( '' !== $username ) {

			$media_array = $this->scrape_instagram( $username );

			if ( is_wp_error( $media_array ) ) {

				echo wp_kses_post( $media_array->get_error_message() );

			} else {

				// filter for images only?
				if ( $images_only = apply_filters( 'wpiw_images_only', false ) ) {
					$media_array = array_filter( $media_array, array( $this, 'images_only' ) );
				}

				// slice list down to required limit.
				$media_array = array_slice( $media_array, 0, $limit );

				// filters for custom classes.
				$ulclass = apply_filters( 'wpiw_list_class', 'instagram-pics instagram-size-' . $size );
				$liclass = apply_filters( 'wpiw_item_class', '' );
				$aclass = apply_filters( 'wpiw_a_class', '' );
				$imgclass = apply_filters( 'wpiw_img_class', '' );
				$template_part = apply_filters( 'wpiw_template_part', 'parts/wp-instagram-widget.php' );
				
				?><ul class="alith-instagram-grid-widget alith-clr alith-row alith-gap-<?php echo esc_attr( $columns_gap ); ?>"><?php
				foreach( $media_array as $item ) {
					// copy the else line into a new file (parts/wp-instagram-widget.php) within your theme and customise accordingly.
					if ( locate_template( $template_part ) !== '' ) {
						include locate_template( $template_part );
					} else {
						echo '<li class="wow fadeInUp alith-col-nr alith-clr alith-col-'. $columns.'"><a href="' . esc_url( $item['link'] ) . '" target="' . esc_attr( $target ) . '"  class="' . esc_attr( $aclass ) . '"><img src="' . esc_url( $item[$size] ) . '"  alt="' . esc_attr( $item['description'] ) . '" title="' . esc_attr( $item['description'] ) . '"  class="' . esc_attr( $imgclass ) . '"/></a></li>';
					}
					
				}
				?></ul><?php
			}
		}

		$linkclass = apply_filters( 'wpiw_link_class', 'clear' );
		$linkaclass = apply_filters( 'wpiw_linka_class', 'more-button' );

		switch ( substr( $username, 0, 1 ) ) {
			case '#':
				$url = '//instagram.com/explore/tags/' . str_replace( '#', '', $username );
				break;

			default:
				$url = '//instagram.com/' . str_replace( '@', '', $username );
				break;
		}

		if ( '' !== $link ) {
			?><p class="follow <?php echo esc_attr( $linkclass ); ?>"><a href="<?php echo trailingslashit( esc_url( $url ) ); ?>" rel="me" target="<?php echo esc_attr( $target ); ?>" class="<?php echo esc_attr( $linkaclass ); ?>"><?php echo wp_kses_post( $link ); ?></a></p><?php
		}

		do_action( 'wpiw_after_widget', $instance );

		echo $args['after_widget'];
	}

	public function form( $instance ) {
		extract( wp_parse_args( (array) $instance, array(
			'title' => __( 'Instagram', 'alith-core' ),
			'username' => '',
			'size' => 'thumbnail',
			'link' => __( 'Follow Me!', 'alith-core' ),
			'number' => 8,
			'target' => '_self',
			'columns'     => '4',
			'columns_gap' => '5',
		) ) );
		
		
		$get_gaps    = alith_get_column_gap_options();
		$get_columns = alith_get_column_options();
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'alith-core' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'username' ) ); ?>"><?php esc_html_e( '@username or #tag', 'alith-core' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'username' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'username' ) ); ?>" type="text" value="<?php echo esc_attr( $username ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of photos', 'alith-core' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'size' ) ); ?>"><?php esc_html_e( 'Photo size', 'alith-core' ); ?>:</label>
			<select id="<?php echo esc_attr( $this->get_field_id( 'size' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'size' ) ); ?>" class="widefat">
				<option value="thumbnail" <?php selected( 'thumbnail', $size ); ?>><?php esc_html_e( 'Thumbnail', 'alith-core' ); ?></option>
				<option value="small" <?php selected( 'small', $size ); ?>><?php esc_html_e( 'Small', 'alith-core' ); ?></option>
				<option value="large" <?php selected( 'large', $size ); ?>><?php esc_html_e( 'Large', 'alith-core' ); ?></option>
				<option value="original" <?php selected( 'original', $size ); ?>><?php esc_html_e( 'Original', 'alith-core' ); ?></option>
			</select>
		</p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'target' ) ); ?>"><?php esc_html_e( 'Open links in', 'alith-core' ); ?>:</label>
			<select id="<?php echo esc_attr( $this->get_field_id( 'target' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'target' ) ); ?>" class="widefat">
				<option value="_self" <?php selected( '_self', $target ); ?>><?php esc_html_e( 'Current window (_self)', 'alith-core' ); ?></option>
				<option value="_blank" <?php selected( '_blank', $target ); ?>><?php esc_html_e( 'New window (_blank)', 'alith-core' ); ?></option>
			</select>
		</p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'columns' ) ); ?>"><?php esc_html_e( 'Columns', 'alith-core' ); ?>:</label>
				<select id="<?php echo esc_attr( $this->get_field_id( 'columns' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'columns' ) ); ?>" class="widefat">
					<?php foreach ( $get_columns as $key ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $columns, $key ); ?>><?php echo esc_html( $key ); ?></option>
					<?php endforeach; ?>
				</select>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'columns_gap' ) ); ?>"><?php esc_html_e( 'Column Gap', 'alith-core' ); ?>:</label>
			<br />
			<select class='alith-select' name="<?php echo esc_attr( $this->get_field_name( 'columns_gap' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'columns_gap' ) ); ?>">
				<?php foreach ( $get_gaps as $key => $val ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $columns_gap, $key ); ?>><?php echo esc_html( $val ); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>"><?php esc_html_e( 'Link text', 'alith-core' ); ?>: <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link' ) ); ?>" type="text" value="<?php echo esc_attr( $link ); ?>" /></label></p>
		<?php

	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['username'] = trim( strip_tags( $new_instance['username'] ) );
		$instance['number'] = ! absint( $new_instance['number'] ) ? 8 : $new_instance['number'];
		$instance['size'] = ( ( 'thumbnail' === $new_instance['size'] || 'large' === $new_instance['size'] || 'small' === $new_instance['size'] || 'original' === $new_instance['size'] ) ? $new_instance['size'] : 'thumbnail' );
		$instance['target'] = ( ( '_self' === $new_instance['target'] || '_blank' === $new_instance['target'] ) ? $new_instance['target'] : '_self' );
		$instance['link'] = strip_tags( $new_instance['link'] );
		$instance['columns']     = intval( $new_instance['columns'] );
		$instance['columns_gap'] = strip_tags( $new_instance['columns_gap'] );
		return $instance;
	}

	// based on https://gist.github.com/cosmocatalano/4544576.
	function scrape_instagram( $username ) {
			$username  = trim( strtolower( $username ) );
			$instagram = get_transient( 'st_instagram_' . sanitize_title_with_dashes( $username ) );
			if ( false === $instagram ) {
				switch ( substr( $username, 0, 1 ) ) {
					case '#':
						$url = 'https://instagram.com/explore/tags/' . str_replace( '#', '', $username );
						break;
					default:
						$url = 'https://instagram.com/' . str_replace( '@', '', $username );
						break;
				}
				$remote = wp_remote_get( $url );
				if ( is_wp_error( $remote ) ) {
					return new WP_Error( 'site_down', esc_html__( 'Unable to communicate with Instagram.', 'stag' ) );
				}
				if ( 200 !== wp_remote_retrieve_response_code( $remote ) ) {
					return new WP_Error( 'invalid_response', esc_html__( 'Instagram did not return a 200.', 'stag' ) );
				}
				$shards      = explode( 'window._sharedData = ', $remote['body'] );
				$insta_json  = explode( ';</script>', $shards[1] );
				$insta_array = json_decode( $insta_json[0], true );
				if ( ! $insta_array ) {
					return new WP_Error( 'bad_json', esc_html__( 'Instagram has returned invalid data.', 'stag' ) );
				}
				if ( isset( $insta_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'] ) ) {
					$images = $insta_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'];
				} elseif ( isset( $insta_array['entry_data']['TagPage'][0]['graphql']['hashtag']['edge_hashtag_to_media']['edges'] ) ) {
					$images = $insta_array['entry_data']['TagPage'][0]['graphql']['hashtag']['edge_hashtag_to_media']['edges'];
				} else {
					return new WP_Error( 'bad_json_2', esc_html__( 'Instagram has returned invalid data.', 'stag' ) );
				}
				if ( ! is_array( $images ) ) {
					return new WP_Error( 'bad_array', esc_html__( 'Instagram has returned invalid data.', 'stag' ) );
				}
				$instagram = array();
				foreach ( $images as $image ) {
					$image = $image['node'];
					switch ( substr( $username, 0, 1 ) ) {
						case '#':
							$type = ( $image['is_video'] ) ? 'video' : 'image';
							$caption = __( 'Instagram Image', 'stag' );
							if ( ! empty( $image['edge_media_to_caption']['edges'][0]['node']['text'] ) ) {
								$caption = $image['edge_media_to_caption']['edges'][0]['node']['text'];
							}
							$instagram[] = array(
								'description' => $caption,
								'link'        => trailingslashit( '//instagram.com/p/' . $image['shortcode'] ),
								'time'        => $image['taken_at_timestamp'],
								'comments'    => $image['edge_media_to_comment']['count'],
								'likes'       => $image['edge_liked_by']['count'],
								'thumbnail'   => preg_replace( '/^https?\:/i', '', $image['thumbnail_resources'][0]['src'] ),
								'small'       => preg_replace( '/^https?\:/i', '', $image['thumbnail_resources'][2]['src'] ),
								'large'       => preg_replace( '/^https?\:/i', '', $image['thumbnail_resources'][4]['src'] ),
								'original'    => preg_replace( '/^https?\:/i', '', $image['display_url'] ),
								'type'        => $type,
							);
							break;
						default:
							$type = ( $image['is_video'] ) ? 'video' : 'image';
							$caption = __( 'Instagram Image', 'stag' );
							if ( ! empty( $image['edge_media_to_caption']['edges'][0]['node']['text'] ) ) {
								$caption = $image['edge_media_to_caption']['edges'][0]['node']['text'];
							}
							$instagram[] = array(
								'description' => $caption,
								'link'        => trailingslashit( 'https://instagram.com/p/' . $image['shortcode'] ),
								'time'        => $image['taken_at_timestamp'],
								'comments'    => $image['edge_media_to_comment']['count'],
								'likes'       => $image['edge_liked_by']['count'],
								'thumbnail'   => $image['thumbnail_resources'][0]['src'],
								'small'       => $image['thumbnail_resources'][2]['src'],
								'large'       => $image['thumbnail_resources'][4]['src'],
								'original'    => $image['display_url'],
								'type'        => $type,
							);
							break;
					}
				}  // End foreach().
				// Do not set an empty transient - should help catch private or empty accounts.
				if ( ! empty( $instagram ) ) {
					$instagram = base64_encode( serialize( $instagram ) );
					set_transient( 'st_instagram_' . sanitize_title_with_dashes( $username ), $instagram);
				}
			}
			if ( ! empty( $instagram ) ) {
				return unserialize( base64_decode( $instagram ) );
			} else {
				return new WP_Error( 'no_images', esc_html__( 'Instagram did not return any images.', 'stag' ) );
			}
	}

	function images_only( $media_item ) {

		if ( 'image' === $media_item['type'] ) {
			return true;
		}

		return false;
	}
}
}
