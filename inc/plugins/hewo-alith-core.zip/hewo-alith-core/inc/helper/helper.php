<?php 
 /**
 * Media uploader (for widgets)
 */
function eiu_add_media_custom($arg,$use_custom_buttons = false ,$value = ""){
    $defaults = array(
        'useid' => false ,
        'hidden' => true,
        'parent_div_class'=> 'custom-image-upload',
        'field_label' => 'upload_image_field_label',        
        'field_name' => 'upload_image_field',
        'field_id' => 'upload_image_field',
        'field_class' => 'upload_image_field',
        'upload_button_id' => 'upload_banner_button',
        'upload_button_class' => 'upload_banner_button',
        'upload_button_text' => 'Upload',
        'remove_button_id' => 'remove_banner_button',
        'remove_button_class' => 'remove_banner_button',
        'remove_button_text' => 'Remove',
        'preview_div_class' => 'preview',
        'preview_div_class2' => 'preview remove_box',
        'preview_div_id' => 'preview',
        'height' => '100',
        'width' => '100'
                    );
        $arguments = wp_parse_args($arg,$defaults);        
        extract($arguments); 
      wp_enqueue_media();
    ?>                                   
   <?php if( ! $use_custom_buttons ): ?>
   <div class="<?php echo $parent_div_class; ?>" id="<?php echo $parent_div_class; ?>">
        <input name="<?php echo $field_name; ?>" id="<?php echo $field_id; ?>" class="<?php echo $field_class; ?>" <?php if($hidden): ?>  type="hidden" <?php else: ?> type="text" <?php endif; ?> value="<?php if ( $value != "") { echo stripslashes($value); }  ?>" />
        <input type="button" class="button button-primary <?php echo $upload_button_class; ?>" id="<?php echo $upload_button_id; ?>"  value="<?php echo $upload_button_text; ?>">
        <input type="button" class="button button-primary <?php echo $remove_button_class; ?>" id="<?php echo $remove_button_id; ?>" <?php  if ( $value == "") {  ?> disabled="disabled" <?php } ?> value="<?php echo $remove_button_text; ?>">
        <div class="<?php echo $preview_div_class; ?>" style="float: none; margin-top: 10px;">
            <img src="<?php  echo stripslashes($value);  ?>" style="max-width: 200px;">
        </div>
    </div>
   <?php endif; ?>
    <?php
        $usesep = ($useid) ? "#" : ".";
        if($useid):
         $field_class = $field_id;
         $upload_button_class = $upload_button_id;
         $remove_button_class = $remove_button_id;
         $preview_div_class = $preview_div_id;
        endif;  
    ?>
    <script type="text/javascript">
		jQuery(document).ready(function($){
			$('<?php echo $usesep.$remove_button_class; ?>').click(function(e) {
				<?php if(!$useid): ?>
			   $(this).parent().find("<?php echo $usesep.$field_class; ?>").val(""); 
			   $(this).parent().find("<?php echo $usesep.$preview_div_class; ?> img").attr("src","").fadeOut("slow");
			   <?php else: ?>
			   $("<?php echo $usesep.$field_class; ?>").val(""); 
			   $("<?php echo $usesep.$preview_div_class; ?> img").attr("src","").fadeOut("slow");
			   <?php endif; ?>
			   $(this).attr("disabled","disabled");
			 return false;   
			});
		var _custom_media = true,
			  _orig_send_attachment = wp.media.editor.send.attachment;
		  $('<?php echo $usesep.$upload_button_class; ?>').click(function(e) {
			var send_attachment_bkp = wp.media.editor.send.attachment;
			var button = $(this);
			var id = button.attr('id').replace('_button', '');
			_custom_media = true;
			wp.media.editor.send.attachment = function(props, attachment){
			  if ( _custom_media ) {
				  <?php if(!$useid): ?>
				button.parent().find("<?php echo $usesep.$field_class; ?>").val(attachment.url);
				button.parent().find("<?php echo $usesep.$preview_div_class; ?> img").attr("src",attachment.url).fadeIn("slow");
				button.parent().find("<?php echo $usesep.$remove_button_class; ?>").removeAttr("disabled");
				if($('.preview img').length > 0){ $('.preview').css('display','block'); };
				<?php else: ?>
				$("<?php echo $usesep.$field_class; ?>").val(attachment.url);
				$("<?php echo $usesep.$preview_div_class; ?> img").attr("src",attachment.url).fadeIn("slow");        
				$("<?php echo $usesep.$remove_button_class; ?>").removeAttr("disabled");
				<?php endif; ?>
			  } else {
				return _orig_send_attachment.apply( this, [props, attachment] );
			  };
			  $('.preview').removeClass('remove_box');
			}
			wp.media.editor.open(button);
			return false;
		  });
		});
    </script>
   <?php  
}

if ( !function_exists( 'alith_single_post_share_icon' ) ) {
    function alith_single_post_share_icon() {
        $str='
        <div class="post-share">                
            <ul class="post-social-icons">
              <li class="facebook"><a class="fb" href="https://www.facebook.com/sharer.php?u='.urlencode(get_permalink()).'%2F&t=" title="Share on Facebook" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li class="twitter"><a class="tw" href="https://twitter.com/intent/tweet?source='.urlencode(get_permalink()).'%2F&text='.urlencode(get_permalink()).'%2F" target="_blank" title="Tweet"><i class="fa fa-twitter"></i></a></li>
              <li class="google-plus"><a class="gp" href="https://plus.google.com/share?url='.urlencode(get_permalink()).'%2F" target="_blank" title="Share on Google+"><i class="fa fa-google-plus"></i></a></li>
              <li class="pinterest"><a href="http://pinterest.com/pin/create/button/?url='.urlencode(get_permalink()).'%2F&description=" target="_blank" title="Pin it"><i class="fa fa-pinterest"></i></a></li>
            </ul>
        </div>
        ';
        return $str;
    }
}