<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
//Twitter Tweet widgets
add_action('widgets_init','alitheme_register_twitter_widget');

function alitheme_register_twitter_widget() {
    register_widget('Alitheme_Theme_Widget_Twitter');
}
// Start class
if ( ! class_exists( 'Alitheme_Theme_Widget_Twitter' ) ) {
	class Alitheme_Theme_Widget_Twitter extends WP_Widget {

	//register widget
	public function __construct()
    {
		{
			parent::__construct(
			  'alitheme_twitter', 
			  esc_html__('Alitheme Twitter', 'alith-core' ),
			  array(
				'description' => esc_html__('Display your avatar, description, social network', 'alith-core' )
			  )
			);
		  }
	}

	//render widget
    function widget( $args, $instance ) {
        extract( $args );
        $title = apply_filters('widget_title', !empty($instance['title']) ? $instance['title'] : '', $instance);
        $title_color = (!empty($instance['title_color'])) ? $instance['title_color'] : '';
        $options['twitter_user'] = (!empty($instance['twitter_user'])) ? $instance['twitter_user'] : '';
        $options['num_tweets'] = (!empty($instance['num_tweets'])) ? $instance['num_tweets'] : 5;

        echo $before_widget;

	    if ( ! empty( $title ) ) {
		    echo $before_title;
		    if ( ! empty( $title_color ) ) {
			    echo '<span style="color:' . esc_attr( $title_color ) . ';">' . esc_attr( $title ) . '</span>';
		    } else {
			    echo esc_attr( $title );
		    }
		    echo $after_title;
	    } ?>

	    <div class="widget-content-wrap">
		    <ul class="twitter-widget-inner">
			    <?php if ( function_exists( 'getTweets' ) ) :
				    $tweets_data = getTweets( $options['num_tweets'], $options['twitter_user'] );
				    if ( ! empty( $tweets_data ) && is_array( $tweets_data ) && empty( $tweets_data['error'] ) ) :
					    foreach ( $tweets_data as $tweet ) :
						    $tweet['text'] = preg_replace( '/\b([a-zA-Z]+:\/\/[\w_.\-]+\.[a-zA-Z]{2,6}[\/\w\-~.?=&%#+$*!]*)\b/i', "<a href=\"$1\" class=\"twitter-link\">$1</a>", $tweet['text'] );
						    $tweet['text'] = preg_replace( '/\b(?<!:\/\/)(www\.[\w_.\-]+\.[a-zA-Z]{2,6}[\/\w\-~.?=&%#+$*!]*)\b/i', "<a href=\"http://$1\" class=\"twitter-link\">$1</a>", $tweet['text'] );
						    $tweet['text'] = preg_replace( "/\b([a-zA-Z][a-zA-Z0-9\_\.\-]*[a-zA-Z]*\@[a-zA-Z][a-zA-Z0-9\_\.\-]*[a-zA-Z]{2,6})\b/i", "<a href=\"mailto://$1\" class=\"twitter-link\">$1</a>", $tweet['text'] );
						    $tweet['text'] = preg_replace( '/([\.|\,|\:|\>|\{|\(]?)#{1}(\w*)([\.|\,|\:|\!|\?|\>|\}|\)]?)\s/i', "$1<a href=\"http://twitter.com/#search?q=$2\" class=\"twitter-link\">#$2</a>$3 ", $tweet['text'] );
						    $tweet['text'] = str_replace( 'RT', ' ', $tweet['text'] );

						    $time = strtotime( $tweet['created_at'] );
						    if ( ( abs( time() - $time ) ) < 86400 ) {
							    $h_time = sprintf( esc_html__( '%s ago', 'alith-core' ), human_time_diff( $time ) );
						    } else {
							    $h_time = date( 'M j, Y', $time );
						    }
						    ?>

						    <li class="twitter-content post-excerpt">								
							    <p><i aria-hidden="true" class="fa fa-twitter"></i><?php echo do_shortcode( $tweet['text'] ); ?></p>
							    <span class="post_meta">
									<span class="meta_date"><i class="fa fa-clock-o" aria-hidden="true"></i><?php echo esc_attr( $h_time ) ?></span>
								</span>
						    </li>

					    <?php endforeach; ?>
				    <?php
				    else :
					    echo '<li><p class="alith-error">' . $tweets_data['error'] . '</p></li>';
				    endif; ?>
			    <?php else : echo '<p class="alith-error">' . esc_html__( 'Please install plugin name "oAuth Twitter Feed for Developers', 'alith-core' ) . '</p>'; ?>
			    <?php endif; ?>

		    </ul><!-- twitter feed -->
	    </div><!-- widget content wrap -->

        <?php
        echo $after_widget;
    }

    //update form
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        delete_transient('aliththeme_alith_tweet_feed');
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['title_color'] = strip_tags($new_instance['title_color']);
        $instance['twitter_user'] = strip_tags($new_instance['twitter_user']);
        $instance['num_tweets'] = absint(strip_tags($new_instance['num_tweets']));
        return $instance;
    }


    //from settings
    function form( $instance ) {

	    $defaults = array(
		    'title'        => esc_html__( 'Latest Tweets', 'alith-core' ),
            'title_color' => '',
		    'twitter_user' => '',
		    'num_tweets'   => 5
	    );
	    $instance = wp_parse_args( (array) $instance, $defaults );
        ?>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><strong><?php esc_attr_e('Title:', 'alith-core');?></strong></label>
            <input type="text" class="widefat"  id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" value="<?php echo esc_attr($instance['title']); ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'twitter_user' )); ?>"><strong><?php esc_attr_e('Twitter Name:', 'alith-core');?></strong></label>
            <input type="text" class="widefat"  id="<?php echo esc_attr($this->get_field_id( 'twitter_user' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'twitter_user' )); ?>" value="<?php echo esc_attr($instance['twitter_user']); ?>"/>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'num_tweets' )); ?>"><strong><?php esc_attr_e('Number of Tweets:', 'alith-core');?></strong></label>
            <input type="text" class="widefat"  id="<?php echo esc_attr($this->get_field_id( 'num_tweets' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'num_tweets' )); ?>" value="<?php echo esc_attr($instance['num_tweets']); ?>"/>
        </p>
	    <p>
		    <label for="<?php echo esc_attr($this->get_field_id('title_color')); ?>"><?php esc_html_e('Title Text Color (hex value):', 'alith-core'); ?></label>
		    <input class="widefat" type="text" id="<?php echo esc_attr($this->get_field_id('title_color')); ?>" name="<?php echo esc_attr($this->get_field_name('title_color')); ?>" value="<?php echo esc_attr($instance['title_color']); ?>"/>
	    </p>
        <p><?php esc_attr_e('You have to ', 'alith-core'); ?><a href="http://dev.twitter.com/apps" target="_blank"><?php esc_attr_e(' Create your Twitter App ', 'alith-core'); ?></a><?php esc_html_e('and install','alith-core'); ?><a href="https://wordpress.org/plugins/oauth-twitter-feed-for-developers/"><?php esc_html_e('"oAuth Twitter Feed for Developers" Plugin','alith-core');?></a></p>
    <?php
    }
}
}
