<?php
/* Change demo directory path */
if ( !function_exists( 'hewo_alith_change_demo_directory_path' ) ):
    function hewo_alith_change_demo_directory_path( $demo_directory_path ) {
        $demo_directory_path = str_replace( '\\', '/', ALITH_CORE_PLUGIN_DIR.'demos/');
        return $demo_directory_path;
    }
endif;
add_filter( 'wbc_importer_dir_path', 'hewo_alith_change_demo_directory_path' );

/*SET MENU LOCATION*/

if ( !function_exists( 'hewo_alith_imported_demo' ) ) {
	function hewo_alith_imported_demo( $demo_active_import) {
		reset( $demo_active_import );
		$current_key = key( $demo_active_import );
		
		// setup menu
		$wbc_menu_array = array( 'default' );
		if ( isset( $demo_active_import[$current_key]['directory'] ) && !empty( $demo_active_import[$current_key]['directory'] ) && in_array( $demo_active_import[$current_key]['directory'], $wbc_menu_array ) ) {
			$main_menu = get_term_by( 'name', 'Main menu', 'nav_menu' );

			if ( isset( $main_menu->term_id ) ) {
				set_theme_mod( 'nav_menu_locations', array(
						'main-menu' 	=> $main_menu->term_id
					)
				);
			}
		}
		
	}
	add_action( 'wbc_importer_after_content_import', 'hewo_alith_imported_demo', 10, 2 );
}

/*REMOVE WIDGETS BEFORE IMPORT*/
if ( ! function_exists( 'hewo_alith_init_before_import' ) ) {
	function bingo_ruby_init_before_import() {
		$sidebars_widgets['sidebar-area']       		= array();
		$sidebars_widgets['headline-content-area']      = array();
		$sidebars_widgets['before-content-area'] 		= array();
		$sidebars_widgets['after-content-area']         = array();
		$sidebars_widgets['sidebar-offcanvas-area']  	= array();
		$sidebars_widgets['footer1-area']         		= array();
		$sidebars_widgets['footer2-area']         		= array();
		$sidebars_widgets['footer3-area']         		= array();
		$sidebars_widgets['footer4-area']         		= array();

		update_option( 'sidebars_widgets', $sidebars_widgets );		
	}

	//remove widget
	add_action( 'wbc_importer_before_widget_import', 'hewo_alith_init_before_import', 10, 2 );
}