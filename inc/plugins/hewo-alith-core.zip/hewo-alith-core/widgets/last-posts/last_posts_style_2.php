<?php 
$width=$instance['width'];
$height=$instance['height'];
$title = $instance['title'];
$postObj = $wpQuery->post;
$count = 1;

if($wpQuery->have_posts()){
	?>	
<?php if($title==''):?>
	<?php if($cat !=0):?>
		<div class="widget-title-cover"><h4 class="widget-title"><a href="<?php echo get_category_link($cat)?>" title="<?php echo get_cat_name($cat)?>"><span><?php echo get_cat_name($cat)?></span></a></h4></div>
	<?php endif;?>
<?php endif;?>

<div class="latest_style_2">
	<?php 
	while ($wpQuery->have_posts()){
		$wpQuery->the_post();
		$postObj = $wpQuery->post;

		$imgUrl = wp_get_attachment_url(get_post_thumbnail_id($postObj->ID));
	
		if(!empty($imgUrl)){
			$imgUrl = $this->get_new_img_url($imgUrl, $width, $height);
		}
	?>
	<?php if($count==1):?>
	<div class="latest_style_2_item_first">
		<?php if(!empty($imgUrl)): ?>						                                                  
		<figure class="alith_post_thumb_big">			
			<a title="<?php the_title_attribute();?>" href="<?php the_permalink();?>"><img src="<?php echo esc_attr($imgUrl);?>" alt="<?php the_title_attribute();?>"/></a>
		</figure>
		<?php endif; ?>
		<h5>
			<a href="<?php the_permalink();?>"><?php the_title();?></a>
		</h5>
		<div class="post_meta">
			<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>" class="meta_author_avatar"><?php echo get_avatar( get_the_author_meta('user_email'), '30'); ?></a>				
			<span class="meta_author_name"><?php the_author_posts_link(); ?></span>
			<span class="meta_date"><i class="fa fa-folder-o" aria-hidden="true"></i><?php echo get_the_category_list(' , '); ?></span>
			<span class="meta_date"><i class="fa fa-clock-o" aria-hidden="true"></i><?php echo get_the_date(); ?></span>

		</div>
	</div>
	<?php else: ?>
	<div class="latest_style_2_item">
		<?php if(!empty($imgUrl)): ?>
			<figure class="alith_news_img"><a href="<?php the_permalink();?>"><img src="<?php echo esc_attr($imgUrl);?>" alt="<?php the_title_attribute();?>"/></a></figure>
		<?php endif; ?>
		<h6><a href="<?php the_permalink();?>"><?php the_title();?></a></h6>
		<div class="post_meta">
			<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>" class="meta_author_avatar"><?php echo get_avatar( get_the_author_meta('user_email'), '30'); ?></a>					
			<span class="meta_author_name"><?php the_author_posts_link(); ?></span>
			<span class="meta_date"><i class="fa fa-clock-o" aria-hidden="true"></i><?php echo get_the_date(); ?></span>
		</div>
	</div>
	<?php endif; ?>
	<?php
		$count ++;
		} //end while			
	} //end if	
	?>	

</div>

	
